CREATE USER admin IDENTIFIED BY storeadm;

CREATE ROLE admin_role IDENTIFIED USING onlinestoredb;

GRANT CONNECT, RESOURCE, DBA TO admin_role;

GRANT admin_role TO admin;

CREATE USER appuser IDENTIFIED BY storeapp;

CREATE ROLE app_role IDENTIFIED USING onlinestoredb;

GRANT SELECT ANY TABLE TO app_role;

GRANT INSERT ANY TABLE TO app_role;

GRANT UPDATE ANY TABLE TO app_role;

GRANT DELETE ANY TABLE TO app_role;

GRANT app_role TO appuser;





