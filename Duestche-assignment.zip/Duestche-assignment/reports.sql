CREATE OR REPLACE FORCE VIEW onlinestoredb.vw_sold_prd_max(order_qty,prduct,country)
AS
SELECT max(itm.quantity*itm.unitprice) a,prd.productid,cntr.countryid
FROM onlinestoredb.order_items itm, onlinestoredb.orders ord,onlinestoredb.products prd,onlinestoredb.warehouses wh,onlinestoredb.locations loc,onlinestoredb.countries cntr
WHERE itm.orderid = ord.orderid
  AND itm.productid = prd.productid
  AND wh.warehouseid = itm.warehouseid
  AND wh.location = loc.locationid
  AND loc.country = cntr.countryid
  AND trunc(ord.orderdate) > trunc(sysdate - 8)
  GROUP BY prd.productid,cntr.countryid;
/

CREATE OR REPLACE FORCE VIEW onlinestoredb.vw_cust_max_ord(order_qty,Customer,country)
AS
SELECT max(itm.quantity*itm.unitprice) a,cust.customerid,cntr.countryid
FROM onlinestoredb.order_items itm, onlinestoredb.orders ord,onlinestoredb.products prd,onlinestoredb.warehouses wh,onlinestoredb.locations loc,onlinestoredb.countries cntr,onlinestoredb.customers cust
WHERE itm.orderid = ord.orderid
  AND itm.productid = prd.productid
  AND wh.warehouseid = itm.warehouseid
  AND wh.location = loc.locationid
  AND loc.country = cntr.countryid
  AND cust.customerid = ord.customerid
  AND trunc(ord.orderdate) > trunc(sysdate - 8)
  GROUP BY cust.customerid,cntr.countryid;
/

