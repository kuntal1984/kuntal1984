CREATE TABLE onlinestoredb.regions(regionid NUMBER(16) PRIMARY KEY, 
                                   regionname VARCHAR2(50));
/
CREATE TABLE onlinestoredb.countries(countryid NUMBER(12) PRIMARY KEY, 
				     countryname VARCHAR2(50), 
                                     region NUMBER(16)
                                     CONSTRAINT contries_fk REFERENCES onlinestoredb.regions
                                     (regionid) );
/
CREATE TABLE onlinestoredb.locations(locationid NUMBER(12) PRIMARY KEY,
                                     address VARCHAR2(30),
                                     postal_code VARCHAR2(20),
                                     city VARCHAR2(15),
                                     state VARCHAR2(15),
                                     country NUMBER(12)
                                     CONSTRAINT loctions_fk REFERENCES onlinestoredb.countries
                                     (countryid) );
/
CREATE TABLE onlinestoredb.warehouses(warehouseid NUMBER(12) PRIMARY KEY,
                                      warehousename VARCHAR2(30),
                                      location NUMBER(12)
                                      CONSTRAINT warehouses_fk REFERENCES onlinestoredb.locations
                                      (locationid) );
/
CREATE TABLE onlinestoredb.employees(employeeid NUMBER(15) PRIMARY KEY,
                                     firstname VARCHAR2(30),
                                     lastname VARCHAR2(30),
                                     email VARCHAR2(30),
                                     phone VARCHAR2(20),
                                     hiredate DATE,
                                     dob DATE,
                                     salary NUMBER(20,5),
                                     manager VARCHAR2(30),
                                     designation VARCHAR2(20),
                                     department NUMBER(12)
                                     CONSTRAINT employees_fk REFERENCES onlinestoredb.department 
                                     (deptid));
/
CREATE TABLE onlinestoredb.department(deptid NUMBER(12) PRIMARY KEY,
                                      departmentname VARCHAR2(20),
                                      location NUMBER(12)
                                      CONSTRAINT department_fk REFERENCES onlinestoredb.locations
                                      (locationid));
/
CREATE TABLE onlinestoredb.product_category(categoryid NUMBER(16) PRIMARY KEY,
                                            categoryname VARCHAR2(40));
/                                            
CREATE TABLE onlinestoredb.products(productid NUMBER(15) PRIMARY KEY,
                                    productname VARCHAR2(50),
                                    description VARCHAR2(200),
                                    standardcost NUMBER(20,5),
                                    listprice NUMBER(20,5),
                                    category NUMBER(16)
                                    CONSTRAINT products_fk REFERENCES onlinestoredb.product_category
                                    (categoryid) );
/
CREATE TABLE onlinestoredb.customers(customerid NUMBER(20) PRIMARY KEY,
                                     name VARCHAR2(60),
                                     address VARCHAR2(200),
                                     website VARCHAR2(100),
                                     Facebook VARCHAR2(100),
                                     Twitter VARCHAR2(100),
                                     WhatsApp NUMBER(25));
/
CREATE TABLE onlinestoredb.contacts(contactid NUMBER(20) PRIMARY KEY,
                                    firstname VARCHAR2(20),
                                    lastname VARCHAR2(20),
                                    email VARCHAR2(30),
                                    phone VARCHAR2(20),
                                    customerid NUMBER(20) 
                                    CONSTRAINT contacts_fk REFERENCES onlinestoredb.customers
                                    (customerid) );
/
CREATE TABLE onlinestoredb.orders(orderid NUMBER(30) PRIMARY KEY,
                                  customerid NUMBER(20)
                                  CONSTRAINT orders_fk REFERENCES onlinestoredb.customers
                                  (customerid),
                                  status VARCHAR2(30),
                                  salesmanid NUMBER(30),
                                  orderdate DATE
                                   );
/
CREATE TABLE onlinestoredb.order_items(orderid NUMBER(30)
                                       CONSTRAINT order_items_fk REFERENCES onlinestoredb.orders
                                       (orderid),
                                       itemid NUMBER(35) PRIMARY KEY,
                                       productid NUMBER(15) CONSTRAINT order_items_fk1 REFERENCES onlinestoredb.products
                                       (productid),
                                       quantity NUMBER(10,5),
                                       unitprice NUMBER(10,5),
                                       inventories_productid NUMBER(18),
                                       warehouseid NUMBER(12) CONSTRAINT order_items_fk2 REFERENCES onlinestoredb.warehouses
                                       (warehouseid) );
/
--Audit tables--

CREATE TABLE onlinestoredb.product_category_audit(id NUMBER(30) PRIMARY KEY,
                                                  old_categoryname VARCHAR2(40),
                                                  new_categoryname VARCHAR2(40),
                                                  username VARCHAR2(40),
                                                  entry_date DATE,
                                                  operation VARCHAR2(20));
/
CREATE TABLE onlinestoredb.order_items_audit(id NUMBER(30) PRIMARY KEY,
                                             old_orderid NUMBER(30),
                                             new_orderid NUMBER(30),
                                             old_productid NUMBER(15),
                                             new_productid NUMBER(15),
                                             old_quantity NUMBER(10,5),
                                             new_quantity NUMBER(10,5),
                                             old_unitprice NUMBER(10,5),
                                             new_unitprice NUMBER(10,5),
                                             old_inventories_productid NUMBER(18),
                                             new_inventories_productid NUMBER(18),
                                             old_warehouseid NUMBER(12),
                                             new_warehouseid NUMBER(12),
                                             username VARCHAR2(40),
                                             entry_date DATE,
                                             operation VARCHAR2(20));
/
CREATE TABLE onlinestoredb.regions_audit(id NUMBER(16) PRIMARY KEY, 
                                         old_regionname VARCHAR2(50),
                                         new_regionname VARCHAR2(50),
                                         username VARCHAR2(40),
                                         entry_date DATE,
                                         operation VARCHAR2(20));
/
--Sequences--

CREATE SEQUENCE onlinestoredb.regions_seq 
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 20;
/
CREATE SEQUENCE onlinestoredb.countries_seq 
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 20;
/
CREATE SEQUENCE onlinestoredb.regions_audit_seq 
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 20;
/
CREATE SEQUENCE onlinestoredb.locations_seq 
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 20;
/
CREATE SEQUENCE onlinestoredb.ord_itm_audit_seq 
MINVALUE 1
START WITH 1
INCREMENT BY 1
CACHE 20;
/

--triggers--


CREATE OR REPLACE TRIGGER  onlinestoredb.tr_regions_audit 
BEFORE INSERT OR UPDATE OR DELETE ON onlinestoredb.regions
FOR EACH ROW
ENABLE
DECLARE
  v_user VARCHAR2(40);
  v_date DATE;
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  
  SELECT user, TO_DATE(sysdate,'DD-MON-YYYY HH24:MI:SS') INTO v_user,v_date FROM DUAL;
    
   IF INSERTING THEN
     INSERT INTO onlinestoredb.regions_audit(id,old_regionname,new_regionname,username,entry_date,operation)
         VALUES(regions_audit_seq.nextval,NULL,:NEW.regionname,v_user,v_date,'INSERT');
    ELSIF DELETING THEN
     INSERT INTO onlinestoredb.regions_audit(id,old_regionname,new_regionname,username,entry_date,operation)
         VALUES(regions_audit_seq.nextval,:OLD.regionname,NULL,v_user,v_date,'DELETE');
    ELSIF UPDATING THEN
     INSERT INTO onlinestoredb.regions_audit(id,old_regionname,new_regionname,username,entry_date,operation)
         VALUES(regions_audit_seq.nextval,:OLD.regionname,:NEW.regionname,v_user,v_date,'UPDATE');
    END IF;
    COMMIT;
   
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Exceptin encountered'||':'|| SQLERRM);

END;
/

CREATE OR REPLACE TRIGGER  onlinestoredb.tr_product_category_audit 
BEFORE INSERT OR UPDATE OR DELETE ON onlinestoredb.product_category
FOR EACH ROW
ENABLE
DECLARE
  v_user VARCHAR2(40);
  v_date DATE;
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  
  SELECT user, TO_DATE(sysdate,'DD-MON-YYYY HH24:MI:SS') INTO v_user,v_date FROM DUAL;
  
  IF INSERTING THEN
     INSERT INTO onlinestoredb.product_category_audit(id,old_categoryname,new_categoryname,username,entry_date,operation)
         VALUES(pc_audit_seq.nextval,NULL,:NEW.categoryname,v_user,v_date,'INSERT');
  ELSIF DELETING THEN
     INSERT INTO onlinestoredb.product_category_audit(id,old_categoryname,new_categoryname,username,entry_date,operation)
         VALUES(pc_audit_seq.nextval,:OLD.categoryname,NULL,v_user,v_date,'DELETE');
  ELSIF UPDATING THEN
     INSERT INTO onlinestoredb.product_category_audit(id,old_categoryname,new_categoryname,username,entry_date,operation)
         VALUES(pc_audit_seq.nextval,:OLD.categoryname,:NEW.categoryname,v_user,v_date,'UPDATE');
  END IF;
  COMMIT;
  
   
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Exceptin encountered'||':'|| SQLERRM);

END;
/


CREATE OR REPLACE TRIGGER  onlinestoredb.tr_order_item_audit 
BEFORE INSERT OR UPDATE OR DELETE ON onlinestoredb.order_items
FOR EACH ROW
ENABLE
DECLARE
  v_user VARCHAR2(40);
  v_date DATE;
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  
  SELECT user, TO_DATE(sysdate,'DD-MON-YYYY HH24:MI:SS') INTO v_user,v_date FROM DUAL;
  
  IF INSERTING THEN
     INSERT INTO onlinestoredb.order_items_audit(id,old_orderid,new_orderid,old_productid,new_productid,old_quantity,new_quantity,old_unitprice,new_unitprice,old_inventories_productid,new_inventories_productid,old_warehouseid,new_warehouseid,username,entry_date,operation)
         VALUES(ord_itm_audit_seq.nextval,NULL,:NEW.orderid,NULL,:NEW.productid,NULL,:NEW.quantity,NULL,:NEW.unitprice,NULL,:NEW.inventories_productid,NULL,:NEW.warehouseid,v_user,v_date,'INSERT');
  ELSIF DELETING THEN
     INSERT INTO onlinestoredb.order_items_audit(id,old_orderid,new_orderid,old_productid,new_productid,old_quantity,new_quantity,old_unitprice,new_unitprice,old_inventories_productid,new_inventories_productid,old_warehouseid,new_warehouseid,username,entry_date,operation)
         VALUES(ord_itm_audit_seq.nextval,:OLD.orderid,NULL,:OLD.productid,NULL,:OLD.quantity,NULL,:OLD.unitprice,NULL,:OLD.inventories_productid,NULL,:OLD.warehouseid,NULL,v_user,v_date,'DELETE');
  ELSIF UPDATING THEN
     INSERT INTO onlinestoredb.order_items_audit(id,old_orderid,new_orderid,old_productid,new_productid,old_quantity,new_quantity,old_unitprice,new_unitprice,old_inventories_productid,new_inventories_productid,old_warehouseid,new_warehouseid,username,entry_date,operation)
         VALUES(ord_itm_audit_seq.nextval,:OLD.orderid,:NEW.orderid,:OLD.productid,:NEW.productid,:OLD.quantity,:NEW.quantity,:OLD.unitprice,:NEW.unitprice,:OLD.inventories_productid,:NEW.inventories_productid,:OLD.warehouseid,:NEW.warehouseid,v_user,v_date,'UPDATE');
  END IF;
  COMMIT;
   
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Exceptin encountered'||':'|| SQLERRM);

END;
/







