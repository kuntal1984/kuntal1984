CREATE TABLE onlinestoredb.regions_bkup(regionid NUMBER(16) PRIMARY KEY, 
                                        regionname VARCHAR2(50));
/
INSERT INTO onlinestoredb.regions_bkup(regionid,regionname) 
SELECT regionid,regionname 
  FROM onlinestoredb.regions;
/
COMMIT;
/
CREATE TABLE onlinestoredb.customers_bkup(customerid NUMBER(20) PRIMARY KEY,
                                          name VARCHAR2(60),
                                          address VARCHAR2(200),
                                          website VARCHAR2(100),
                                          Facebook VARCHAR2(100),
                                          Twitter VARCHAR2(100),
                                          WhatsApp NUMBER(25));
/
INSERT INTO onlinestoredb.customers_bkup(customerid,name,address,website,Facebook,Twitter,WhatsApp)
SELECT customerid,name,address,website,Facebook,Twitter,WhatsApp
 FROM  onlinestoredb.customers;
/
COMMIT;
/